package com.example.kidscorner;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Hearlist extends AppCompatActivity {
    ListView l1;
    SQLiteDatabase db;
    //String str[]={"The Foolish Donkey","The Greedy Lion","The Bear And Two Friends","The Foolish Donkey"};
    ArrayList<String> name=new ArrayList<String>();
    ArrayList<String> story=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hearlist);

        l1=(ListView)findViewById(R.id.list);

        db = openOrCreateDatabase("Storydb", Context.MODE_PRIVATE, null);
        if (db != null) {
            //Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }

        db.execSQL("Create table if not exists story(name VARCHAR,review VARCHAR);");

        Cursor c = db.rawQuery("SELECT * FROM story", null);
        if (c.getCount() == 0) {
            Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_SHORT).show();
            return;
        }
        while (c.moveToNext()) {
            String nm=c.getString(0).toString();
            name.add(nm);
            String stry=c.getString(1).toString();
            story.add(stry);

        }
        ArrayAdapter<String> ad = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,name);
        l1.setAdapter(ad);

        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent in = new Intent(Hearlist.this, Hearforme2.class);
                //startActivity(in);
                in.putExtra("pos",position);
                in.putExtra("name", name.get(position));
                in.putExtra("stry", story.get(position));
//               String a= parent.getItemAtPosition(position).toString();
//                Toast.makeText(getApplicationContext()," "+a, Toast.LENGTH_SHORT).show();

                startActivity(in);
            }

        });

    }


}
