package com.example.kidscorner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

public class Rowboat extends AppCompatActivity {
   WebView wv;
    TextView t1;
    ImageView i1;
    Integer pos;
    Integer img[]={R.drawable.row,R.drawable.diddle,R.drawable.johny,R.drawable.sheep,R.drawable.jack};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rowboat);
        t1=(TextView)findViewById(R.id.t1);

        i1=(ImageView)findViewById(R.id.i1);
        Intent in=getIntent();
        int i=in.getIntExtra("pos",0);
        String s=in.getStringExtra("name");
        t1.setText(s);
        i1.setImageResource(img[i]);

        wv=(WebView)findViewById(R.id.wv);
        wv.loadUrl("https://www.youtube.com/watch?v=SumWtHOOvy0");
    }
}
