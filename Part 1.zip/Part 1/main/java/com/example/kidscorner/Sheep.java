package com.example.kidscorner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Sheep extends AppCompatActivity {
    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheep);


        wv=(WebView)findViewById(R.id.wv);
        wv.loadUrl("https://www.youtube.com/watch?v=1dttq5p0xUM");
    }
}
