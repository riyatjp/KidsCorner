package com.example.kidscorner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Tom3 extends AppCompatActivity {
    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tom3);

        wv=(WebView)findViewById(R.id.wv);
        wv.loadUrl("https://www.youtube.com/watch?v=-qagpwPP-VU");
    }
}
