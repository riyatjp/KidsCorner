package com.example.kidscorner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menupage extends AppCompatActivity {
    Button strybtn,rhybtn,carbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menupage);
        strybtn=(Button)findViewById(R.id.strybtn);
        rhybtn=(Button)findViewById(R.id.rhybtn);
        carbtn=(Button)findViewById(R.id.carbtn);

        strybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menupage.this,Strymenu.class);
                startActivity(intent);
            }

        });

        rhybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Menupage.this,Rhylist.class);
                startActivity(in);
            }
        });

        carbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Menupage.this,Carlist.class);
                startActivity(in);
            }
        });
    }

}
