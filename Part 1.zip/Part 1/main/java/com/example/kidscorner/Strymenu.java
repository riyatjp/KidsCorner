package com.example.kidscorner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Strymenu extends AppCompatActivity {
Button readbtn,hearbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_strymenu);

        readbtn=(Button)findViewById(R.id.readbtn);
        hearbtn=(Button)findViewById(R.id.hearbtn);

        readbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Strymenu.this,Readlist.class);
                startActivity(in);
            }
        });

        hearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Strymenu.this,Hearlist.class);
                startActivity(in);
            }
        });
    }
}
