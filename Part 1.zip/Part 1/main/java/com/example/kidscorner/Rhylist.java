package com.example.kidscorner;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Rhylist extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readlist);


        lv=(ListView)findViewById(R.id.lv);
        myadapter1 adb=new myadapter1(this);
        lv.setAdapter(adb);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                if (position == 0) {
                    Intent in = new Intent(Rhylist.this, Rowboat.class);
                    startActivity(in);
                }
                if(position==1) {
                    Intent in = new Intent(Rhylist.this, Diddle.class);
                    startActivity(in);
                }
                if(position==2) {
                    Intent in = new Intent(Rhylist.this, Johny.class);
                    startActivity(in);
                }
                if(position==3) {
                    Intent in = new Intent(Rhylist.this, Sheep.class);
                    startActivity(in);
                }
                if(position==4) {
                    Intent in = new Intent(Rhylist.this, Jack.class);
                    startActivity(in);
                }



            }

        });
    }
}

class SingleRoww
{
    String title;
    //String description;
    int image;
    SingleRoww(String title,int image) {
        this.title = title;
        //this.description = description;
        this.image = image;
    }
}

class myadapter1 extends BaseAdapter {
    ArrayList<SingleRow> list;
    Context context;
    public myadapter1(Context c) {
        this.context=c;
        list=new ArrayList<SingleRow>();
        String[] titles ={"Row Row Your Boat","Hey Diddle Diddle","Johny Johny Yes Papa","Baa Baa Black Sheep","Jack And Jill"};
        int[] images={R.drawable.row1,R.drawable.diddle,R.drawable.johny1,R.drawable.sheep1,R.drawable.jack1};
        for(int i = 0;i < 5; i++) {
            SingleRow s= new SingleRow(titles[i], images[i]);
            list.add(s);
        }

    }

    @Override
    public int getCount() {
        return list.size();

    }

    @Override
    public Object getItem(int position) {
        return 0;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.layout1, parent, false);
        TextView title = (TextView) row.findViewById(R.id.textView);
        //TextView description = (TextView) row.findViewById(R.id.textView2);
        ImageView image = (ImageView) row.findViewById(R.id.imageView);

        SingleRow singleRow = list.get(position);
        title.setText(singleRow.title);
        //description.setText(singleRow.description);
        image.setImageResource(singleRow.image);
        return row;

    }
}

