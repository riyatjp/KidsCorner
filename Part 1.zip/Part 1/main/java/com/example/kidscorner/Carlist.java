package com.example.kidscorner;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Carlist extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carlist);

        lv=(ListView)findViewById(R.id.lv);
        myadapter2 ad=new myadapter2(this);
        lv.setAdapter(ad);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                if (position == 0) {
                    Intent in = new Intent(Carlist.this, Tom1.class);
                    startActivity(in);
                }
                if(position==1) {
                    Intent in = new Intent(Carlist.this, Tom2.class);
                    startActivity(in);
                }
                if(position==2) {
                    Intent in = new Intent(Carlist.this, Tom3.class);
                    startActivity(in);
                }
                if(position==3) {
                    Intent in = new Intent(Carlist.this, Rapunzel.class);
                    startActivity(in);
                }
                if(position==4) {
                    Intent in = new Intent(Carlist.this, Junglebuk.class);
                    startActivity(in);
                }



            }

        });
    }
}

class SingleRow2
{
    String title;
    //String description;
    int image;
    SingleRow2(String title,int image) {
        this.title = title;
        //this.description = description;
        this.image = image;
    }
}

class myadapter2 extends BaseAdapter {
    ArrayList<SingleRow2> list;
    Context context;
    public myadapter2(Context c) {
        this.context=c;
        list=new ArrayList<SingleRow2>();
        String[] titles ={"Tom And Jerry","Tom And Jerry","Tom And Jerry","Oswald","Oswald"};
        int[] images={R.drawable.tj,R.drawable.tj,R.drawable.tj,R.drawable.oswald1,R.drawable.oswald1};
        for(int i = 0;i < 5; i++) {
            SingleRow2 s= new SingleRow2(titles[i], images[i]);
            list.add(s);
        }

    }

    @Override
    public int getCount() {
        return list.size();

    }

    @Override
    public Object getItem(int position) {
        return 0;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.layout2, parent, false);
        TextView title = (TextView) row.findViewById(R.id.textView);
        //TextView description = (TextView) row.findViewById(R.id.textView2);
        ImageView image = (ImageView) row.findViewById(R.id.imageView);

        SingleRow2 singleRow = list.get(position);
        title.setText(singleRow.title);
        //description.setText(singleRow.description);
        image.setImageResource(singleRow.image);
        return row;

    }
}

