package com.example.kidscorner;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Addstry extends AppCompatActivity {
    EditText e1,e2;
    Button b;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstry);

        e1=(EditText)findViewById(R.id.e1);
        e2=(EditText)findViewById(R.id.e2);
        b=(Button)findViewById(R.id.b);

        db = openOrCreateDatabase("Storydb", Context.MODE_PRIVATE, null);
        if (db != null) {
            //Toast.makeText(getApplicationContext(), "Created", Toast.LENGTH_LONG).show();
        }
        db.execSQL("Create table if not exists story(name VARCHAR,review VARCHAR);");


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1.getText().toString().trim().length() == 0 || e2.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("Insert into story values('" + e1.getText() + "','" + e2.getText() + "');");
                //showMessage("Success", "Records added");
                Toast.makeText(getApplicationContext(), "Your story has been saved", Toast.LENGTH_SHORT).show();
                clearText();
            }
        });
   }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        e1.setText("");
        e2.setText("");
        e1.requestFocus();
    }
}


