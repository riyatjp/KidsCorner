package com.example.kidscorner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Hearforme2 extends AppCompatActivity {

    TextView t1,t2;
    //ImageView i1;
    //Integer img[]={R.drawable.cinderella,R.drawable.snow,R.drawable.oswald};
//String d[]={"A salt seller used to carry the salt bag on his donkey to the market every day.\n" +
//        "On the way they had to cross a stream. One day the donkey suddenly tumbled down the stream and the salt bag also fell into the water. The salt dissolved in the water and hence the bag became very light to carry. The donkey was happy.\n" +
//        "Then the donkey started to play the same trick every day.\n" +
//        "The salt seller came to understand the trick and decided to teach a lesson to it. The next day he loaded a cotton bag on the donkey.\n" +
//        "Again it played the same trick hoping that the cotton bag would be still become lighter.\n" +
//        "But the dampened cotton became very heavy to carry and the donkey suffered. It learnt a lesson. It didn’t play the trick anymore after that day, and the seller was happy.\n" +
//        "Moral of the story: \n" +
//        "Luck won’t favor always.\n","It was an incredibly hot day, and a lion was feeling very hungry.\n" +
//        "He came out of his den and searched here and there. He could find only a small hare. He caught the hare with some hesitation. “This hare can’t fill my stomach” thought the lion.\n" +
//        "As the lion was about to kill the hare, a deer ran that way. The lion became greedy. He thought;\n" +
//        "“Instead of eating this small hare, let me eat the big deer.”\n" +
//        "He let the hare go and went behind the deer. But the deer had vanished into the forest. The lion now felt sorry for letting the hare off.\n" +
//        "Moral of the story:\n" +
//        "A bird in hand is worth two in the bush.","Vijay and Raju were friends. On a holiday they went walking into a forest, enjoying the beauty of nature. Suddenly they saw a bear coming at them. They became frightened.\n" +
//        "Raju, who knew all about climbing trees, ran up to a tree and climbed up quickly. He didn’t think of Vijay. Vijay had no idea how to climb the tree.\n" +
//        "Vijay thought for a second. He’d heard animals don’t prefer dead bodies, so he fell to the ground and held his breath. The bear sniffed him and thought he was dead. So, it went on its way.\n" +
//        "Raju asked Vijay;\n" +
//        "“What did the bear whisper into your ears?”\n" +
//        "Vijay replied, “The bear asked me to keep away from friends like you” …and went on his way.\n" +
//        "Moral of the story:\n" +
//        "A friend in need is a friend indeed.\n",
//    "A salt seller used to carry the salt bag on his donkey to the market every day.\n" +
//            "On the way they had to cross a stream. One day the donkey suddenly tumbled down the stream and the salt bag also fell into the water. The salt dissolved in the water and hence the bag became very light to carry. The donkey was happy.\n" +
//            "Then the donkey started to play the same trick every day.\n" +
//            "The salt seller came to understand the trick and decided to teach a lesson to it. The next day he loaded a cotton bag on the donkey.\n" +
//            "Again it played the same trick hoping that the cotton bag would be still become lighter.\n" +
//            "But the dampened cotton became very heavy to carry and the donkey suffered. It learnt a lesson. It didn’t play the trick anymore after that day, and the seller was happy.\n" +
//            "Moral of the story: \n" +
//            "Luck won’t favor always."};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hearforme2);

            t1=(TextView)findViewById(R.id.t1);
            //i1=(ImageView)findViewById(R.id.i1);
            t2=(TextView)findViewById(R.id.t);

        Intent in = getIntent();
        //int i=in.getIntExtra("name",0);
        String s = in.getStringExtra("name");
        String t = in.getStringExtra("stry");
        //Toast.makeText(getApplicationContext(),t,Toast.LENGTH_SHORT).show();
//            // i1.setImageResource(img[i]);
        t1.setText(s);
        t2.setText(t);



    }
    }

