package com.example.kidscorner;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Review extends AppCompatActivity {
    EditText e1,e2;
    Button b,b1;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        e1 = (EditText) findViewById(R.id.et);
        e2 = (EditText) findViewById(R.id.et1);
        b = (Button) findViewById(R.id.b);
        b1 = (Button) findViewById(R.id.b1);

        db = openOrCreateDatabase("Reviewdb", Context.MODE_PRIVATE, null);

        if (db != null) {
            //Toast.makeText(getApplicationContext(), "Created", Toast.LENGTH_LONG).show();
        }
        db.execSQL("Create table if not exists reviewck(name VARCHAR,review VARCHAR);");


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1.getText().toString().trim().length() == 0 || e2.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("Insert into reviewck values('" + e1.getText() + "','" + e2.getText() + "');");
                //showMessage("Success", "Records added");
                Toast.makeText(getApplicationContext(), "Thank you for your review", Toast.LENGTH_SHORT).show();
                clearText();
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c = db.rawQuery("Select * from reviewck", null);
                if (c.getCount() == 0) {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (c.moveToNext()) {
                    buffer.append("Name: " + c.getString(0) + "\n");
                    buffer.append("Review: " + c.getString(1) + "\n");
                }
                showMessage("Reviews", buffer.toString());

            }
        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        e1.setText("");
        e2.setText("");
        e1.requestFocus();
    }
}
